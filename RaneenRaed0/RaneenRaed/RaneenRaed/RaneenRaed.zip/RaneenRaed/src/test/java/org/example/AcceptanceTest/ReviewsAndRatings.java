package org.example.AcceptanceTest;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Given;
import static org.junit.Assert.assertTrue;

public class ReviewsAndRatings
{

    private Product product;
    private InstallationService installationService;

    // Assume you have appropriate methods to handle products and installation services

    @Given("a customer is viewing a product")
    public void aCustomerIsViewingAProduct()
    {
        product = getProductById("123");
        // Get product by ID, replace with actual logic
    }

    @When("they leave a review and rating for the product")
    public void theyLeaveAReviewAndRatingForTheProduct()
    {
        product.addReview("Great product!", 5);
        // Assuming addReview method exists in Product class
    }

    @Then("the review and rating should be submitted successfully")
    public void theReviewAndRatingShouldBeSubmittedSuccessfully()
    {
        assertTrue(product.getAverageRating() > 0); // Assuming getAverageRating method exists in Product class
        assertTrue(product.getReviews().size() > 0);
    }

    @Given("a customer has requested an installation service")
    public void aCustomerHasRequestedAnInstallationService()
    {
        installationService = getInstallationServiceById("456");
        // Get installation service by ID, replace with actual logic
    }

    @When("they leave a review and rating for the installation service")
    public void theyLeaveAReviewAndRatingForTheInstallationService()
    {
        installationService.addReview("Excellent service!", 5);
        // Assuming addReview method exists in InstallationService class
    }

    @Given("there are multiple reviews and ratings for a product")
    public void thereAreMultipleReviewsAndRatingsForAProduct()
    {
        product = getProductById("123");
        // Get product by ID, replace with actual logic
        product.addReview("Good product!", 4); // Add multiple reviews for testing
        product.addReview("Not bad.", 3);
    }

    @When("customers view the product page")
    public void customersViewTheProductPage()
    {
        // No specific action needed for this step
    }

    @Then("the average rating and reviews should be displayed")
    public void theAverageRatingAndReviewsShouldBeDisplayed()
    {
        assertTrue(product.getAverageRating() > 0); // Assuming getAverageRating method exists in Product class
        assertTrue(product.getReviews().size() > 0);
    }

    @Given("there are multiple reviews and ratings for an installation service")
    public void thereAreMultipleReviewsAndRatingsForAnInstallationService()
    {
        installationService = getInstallationServiceById("456");
        // Get installation service by ID, replace with actual logic
        installationService.addReview("Very professional!", 5); // Add multiple reviews for testing
        installationService.addReview("Could be better.", 3);
    }

    @When("customers view the installation service page")
    public void customersViewTheInstallationServicePage()
    {
        // No specific action needed for this step
    }
}
