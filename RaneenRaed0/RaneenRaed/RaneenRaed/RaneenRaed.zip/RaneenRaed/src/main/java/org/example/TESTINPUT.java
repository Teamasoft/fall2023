package org.example;

public class TESTINPUT
{

}
